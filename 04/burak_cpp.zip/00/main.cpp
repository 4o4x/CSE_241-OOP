#include <iostream>
#include <vector>
#include "dayofyearset.h"

using namespace std;
using namespace sBurakYasar;


int main(){

    vector<DayofYearSet :: DayofYear> y; 

    DayofYearSet :: DayofYear z;
    
    
    DayofYearSet :: DayofYear k;
    
    y.push_back(k);
    DayofYearSet a(y);
    
   // y.pop_back();

    k.setAll(5,4);
    
    y.push_back(k);

    z.setAll(7,7);

    y.push_back(z);
    

    DayofYearSet x(y);
    //DayofYearSet a;

    DayofYearSet q;
    q = x^a;

    cout << x;
    //x.remove(1);
    cout << q;
    cout << a;

    //cout << q;
    
    //cout << !(x + a) << endl;
    //cout << ((!x)^(!a)) << endl;

    //cout << ((!x)^(!a)) - (!(x + a)) ;

    //cout << "ficSize: " << (x^a).size() << endl;

    /* if((!(x + a)) == ((!x)^(!a)))
    cout << "its working " << endl; */

    cout << x.getTotalDoy() << endl;
}